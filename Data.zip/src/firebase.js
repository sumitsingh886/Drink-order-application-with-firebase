// Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
import { initializeApp } from "firebase/app";
import { getFirestore } from "@firebase/firestore"


// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCWPReGeEKSLLlQ0NwRxMMcnj_wRYG14Pk",
  authDomain: "beverage-ordering-application.firebaseapp.com",
  databaseURL: "https://beverage-ordering-application-default-rtdb.firebaseio.com",
  projectId: "beverage-ordering-application",
  storageBucket: "beverage-ordering-application.appspot.com",
  messagingSenderId: "585417630167",
  appId: "1:585417630167:web:54e3e888a9d50a1ef22b92"
};

// Initialize Firebase
const firebaseApp = initializeApp(firebaseConfig);
// const app = initializeApp(firebaseConfig);
export const firestore = getFirestore(firebaseApp)
import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/firestore";

const firebaseApp = firebase.initializeApp({
  apiKey: "AIzaSyBBV3JmKYrmjAcvZHWNchbhlRuFeYP6BYs",
  authDomain: "beverages-89596.firebaseapp.com",
  projectId: "beverages-89596",
  storageBucket: "beverages-89596.appspot.com",
  messagingSenderId: "89046984953",
  appId: "1:89046984953:web:586df8e8cf0ff6b9ed1a28",
  measurementId: "G-S27N3SZ6PC"
});

const db = firebaseApp.firestore();
export default db;